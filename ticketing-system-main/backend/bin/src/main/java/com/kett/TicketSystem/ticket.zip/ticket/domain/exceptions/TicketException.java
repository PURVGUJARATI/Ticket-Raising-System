package com.kett.TicketSystem.ticket.domain.exceptions;

public class TicketException extends RuntimeException {
    public TicketException(String message) {
        super(message);
    }
}
